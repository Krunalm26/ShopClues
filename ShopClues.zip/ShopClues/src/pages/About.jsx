import React from 'react';
import './About.css';  // Import the CSS file here

const About = () => {
  return (
    <div className="about-container">
      {/* Company Introduction */}
      <section className="about-intro">
        <h1>About Us</h1>
        <p>
          Welcome to Indus, a leading e-commerce platform where you can find a wide variety of products, from fashion to electronics. Our goal is to deliver the best shopping experience to our customers, offering top-notch products and excellent customer service.
        </p>
      </section>

      {/* Our Mission Section */}
      <section className="about-mission">
        <h2>Our Mission</h2>
        <p>
          At Indus, we are committed to creating a user-friendly platform that provides seamless and enjoyable shopping experiences. We aim to connect millions of shoppers with quality products at competitive prices.
        </p>
      </section>

      {/* Team or Key Features Section */}
      <section className="about-team">
        <h2>Meet Our Team</h2>
        <div className="team-cards">
          <div className="team-card">
            <h3>Krunal Mistri</h3>
            <p>CEO & Founder</p>
          </div>
        
          
        </div>
      </section>
    </div>
    
  );
};

export default About;
