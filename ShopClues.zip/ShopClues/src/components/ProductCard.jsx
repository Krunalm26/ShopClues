import React, { useState } from 'react';
import './ProductCard.css'; // Import the CSS file for styling

const ProductCard = ({ product }) => {
  const [isFavorite, setIsFavorite] = useState(() => {
    const favorites = JSON.parse(localStorage.getItem('favorites')) || [];
    return favorites.some(item => item.id === product.id);
  }); // Initialize favorite status based on localStorage

  const handleAddToCart = () => {
    const existingCart = JSON.parse(localStorage.getItem('cart')) || [];
    const isItemInCart = existingCart.find(item => item.id === product.id);

    if (isItemInCart) {
      
      alert('Item is already in the cart!');
    } else {
      const newCart = [...existingCart, product];
      localStorage.setItem('cart', JSON.stringify(newCart));
      
      alert('Item added to cart!');
    }
  };

  const handleToggleFavorite = () => {
    const existingFavorites = JSON.parse(localStorage.getItem('favorites')) || [];

    if (!isFavorite) {
      // Add to favorites
      const newFavorites = [...existingFavorites, product];
      localStorage.setItem('favorites', JSON.stringify(newFavorites));
      
      alert('Added to favorites!');
    } else {
      // Remove from favorites
      const updatedFavorites = existingFavorites.filter(item => item.id !== product.id);
      localStorage.setItem('favorites', JSON.stringify(updatedFavorites));
      
      
      alert('Removed from favorites!');
    }

    setIsFavorite(!isFavorite);
  };

  return (
    <div className="product-card">
      <div className="image-container">
        <img src={product.image} alt={product.title} />
        <button
          className={`favorite-btn ${isFavorite ? 'favorited' : ''}`}
          onClick={handleToggleFavorite}
          aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          {isFavorite ? '❤️' : '🤍'}
        </button>
      </div>
      <h3>{product.title}</h3>
      <p>Price: ₹{product.price}</p>
      <button className="add-to-cart-btn" onClick={handleAddToCart}>
        Add to Cart
      </button>

      {/* Footer Section */}
      <div className="product-footer">
        <p>
          <i className="fas fa-truck"></i> Free delivery for orders over ₹1500
        </p>
        <p>
          <i className="fas fa-info-circle"></i> 30-day return policy
        </p>
      </div>
    </div>
  );
};

export default ProductCard;
